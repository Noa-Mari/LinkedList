using System;
using System.Collections.Generic;
using LinkedList;

namespace LinkedList
{
    public class MyItem : IMyItem
    {
        public object Content { get; set; }
        public IMyItem NextItem { get; set; }

        public MyItem(object content)
        {
            Content = content;
            NextItem = null;
        }
    }

    public interface IMyItem
    {
        object Content { get; set; }
        MyItem NextItem { get; set; }
    }
}